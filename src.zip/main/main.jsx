import './main.css';
import img from '../asset/student.png'
import bg from '../asset/bg.png';

function Main(){
    return<>
        <div className='main'>
            <img src={bg} className='bg'></img>
            <div className='left'>
                <h2>"Your Pathway to IT Mastery Starts Here."</h2>
                <button>Enrollment</button>
            </div>
            <div className='right'>
                <img src={img} className='img'></img>
            </div>
        </div>
    </>
}

export default Main;