import './header.css';
import divine from '../asset/divine-logo.png';
import Nav from './navbar/nav';
import mscit from '../asset/mscit-logo.png';


function Header(){
    return<>
        <div className='header'>
            <img src={divine} className='logo'></img>
            <Nav/>
            <img src={mscit} className='logo'></img> 
        </div>
    </>
}

export default Header;