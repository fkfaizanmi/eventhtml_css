import Cards from "./courseCards/cards";
import './course.css';
import smlogo from '../asset/smart-phone-png.webp';

function CourseCards(){
    return <>
    <div className="services">
        <h1><span>------</span> Our Services <span>------</span></h1>
    </div>
    <div className="container">
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
        <Cards courseImg={smlogo} courseTitle={"Learning"} courseDes={"Expertly Crafted Curriculum by IT Professionals"}/>
    </div>
    </>
}


export default CourseCards;