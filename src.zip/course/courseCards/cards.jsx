import './cards.css';

function Cards(props){
    return(
    <div className="box">
        <div className="box-img">
            <img src={props.courseImg} alt={props.courseTitle} className='bimg'/>
        </div>
        <div className="box-content">
            <h2 className='card-h2'>{props.courseTitle}</h2>
            <p className='card.p'>{props.courseDes}</p>
            <button className='card-b'>Read More</button>
        </div>
    </div>
    )  
}

export default Cards